<div id="export-sektoral-area" class="space-y-6 pb-8">
    <!-- BOX 1: Header Utama -->
    <div class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 bg-surface-card p-6 md:p-8 rounded-[32px] shadow-sm border border-border-card relative overflow-hidden">
        <div class="absolute top-0 right-0 w-32 h-32 bg-bg-ambient rounded-bl-full -mt-8 -mr-8 blur-3xl opacity-50 pointer-events-none"></div>
        <div class="relative z-10">
            <h1 class="text-3xl font-bold tracking-tight text-text-main">Peringkat Sektoral</h1>
            <p class="mt-2 text-sm text-text-muted">Periode: 16 Agustus - 30 September 2026 (46 hari) | Dibuat: {{ $lastUpdated }}</p>
        </div>
        <div class="relative z-10 flex flex-col sm:flex-row gap-3">
            <!-- Export Actions -->
            <div class="flex space-x-2 bg-surface-subtle p-1 rounded-full border border-border-card/60 export-btn-hide justify-center items-center shrink-0">
                <button onclick="exportToJPG('export-sektoral-area', 'Peringkat_Sektoral')" class="inline-flex items-center px-4 py-2 rounded-full text-xs font-bold bg-white text-text-muted hover:text-text-main shadow-sm transition-colors">
                    <svg class="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg>
                    JPG
                </button>
                <button onclick="exportToPDF('export-sektoral-area', 'Peringkat_Sektoral')" class="inline-flex items-center px-4 py-2 rounded-full text-xs font-bold bg-white text-text-muted hover:text-text-main shadow-sm transition-colors">
                    <svg class="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                    PDF
                </button>
            </div>
            <!-- Search -->
            <div class="relative w-full sm:w-64 export-btn-hide">
                <input type="text" wire:model.live.debounce.300ms="search" placeholder="Cari nama atau NIK..." class="w-full pl-10 pr-4 py-2.5 bg-surface-subtle border border-border-card rounded-full text-sm focus:ring-2 focus:ring-telkom-red focus:border-telkom-red transition-all text-text-main placeholder-text-muted shadow-sm">
                <svg class="w-4 h-4 absolute left-3.5 top-3 text-text-muted" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
            </div>
            <button wire:click="loadData" class="export-btn-hide inline-flex items-center justify-center p-2.5 text-text-muted bg-surface-subtle hover:bg-white hover:text-text-main border border-border-card rounded-full shadow-sm transition-colors shrink-0" title="Refresh Data">
                <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
            </button>
        </div>
    </div>

    <!-- BOX 2: Parameter Penilaian -->
    <div class="bg-surface-card border border-border-card rounded-[32px] shadow-sm p-4 sm:p-6">
        <h3 class="text-sm font-bold text-text-main mb-4 pl-1">Parameter Penilaian</h3>
        <div class="overflow-x-auto custom-scrollbar">
            <table class="w-full text-left border-separate border-spacing-0">
                <thead>
                    <tr>
                        <th class="px-5 py-4 font-bold text-text-main uppercase tracking-wider text-[11px] bg-gray-100 align-middle rounded-l-full min-w-[200px]">Parameter</th>
                        <th class="px-5 py-4 font-bold text-text-main uppercase tracking-wider text-[11px] bg-gray-100 align-middle">Bobot / Nilai</th>
                        <th class="px-5 py-4 font-bold text-text-main uppercase tracking-wider text-[11px] bg-gray-100 rounded-r-full text-center align-middle min-w-[100px]">Aksi</th>
                    </tr>
                </thead>
                <tbody class="[&>tr:not(:last-child)>td]:border-b [&>tr:not(:last-child)>td]:border-border-card/50 text-[13px] text-text-main">
                    @foreach($parameters as $param)
                        <tr class="hover:bg-surface-subtle transition-colors group">
                            <td class="px-5 py-3.5 text-sm text-text-muted font-medium w-2/3">{{ $param['name'] }}</td>
                            <td class="px-5 py-3.5 text-sm text-text-main font-bold">{{ $param['value'] }}</td>
                            <td class="no-export px-5 py-3.5 text-center whitespace-nowrap sticky right-0 bg-surface-card group-hover:bg-surface-subtle transition-colors">
                                <button class="p-1.5 sm:px-4 sm:py-1.5 rounded-lg sm:rounded-full bg-white border border-border-card text-text-muted hover:text-telkom-red hover:border-telkom-red shadow-sm transition-all inline-flex items-center justify-center mx-auto" title="Edit Bobot">
                                    <svg class="w-4 h-4 sm:mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                    <span class="hidden sm:inline text-xs font-bold">Edit</span>
                                </button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <!-- Segmented Control (Pill Toggle) Animasi Halus dengan AlpineJS -->
    <div x-data="{ localTab: '{{ $activeTab }}' }" class="export-btn-hide relative bg-white rounded-full p-1 shadow-sm flex w-full max-w-2xl mx-auto border border-gray-200 mt-8 mb-4 overflow-hidden">
        
        <!-- Sliding Red Indicator -->
        <div class="absolute top-1 bottom-1 w-[calc(33.333%-0.166rem)] bg-telkom-red rounded-full transition-transform duration-300 ease-out shadow-sm"
             :style="`transform: translateX(${localTab === '1_PSB_B2C' ? '0' : (localTab === '2_ASSR_B2C' ? '100%' : '200%')}); left: 0.25rem;`">
        </div>

        <!-- Buttons -->
        <button @click="localTab = '1_PSB_B2C'; $wire.setTab('1_PSB_B2C')" class="flex-1 relative z-10 py-2.5 text-sm sm:text-[15px] font-bold rounded-full transition-colors duration-300" :class="localTab === '1_PSB_B2C' ? 'text-white' : 'text-gray-600 hover:text-gray-900'">
            PSB B2C
        </button>
        <button @click="localTab = '2_ASSR_B2C'; $wire.setTab('2_ASSR_B2C')" class="flex-1 relative z-10 py-2.5 text-sm sm:text-[15px] font-bold rounded-full transition-colors duration-300" :class="localTab === '2_ASSR_B2C' ? 'text-white' : 'text-gray-600 hover:text-gray-900'">
            ASSURANCE B2C
        </button>
        <button @click="localTab = '3_ASSR_B2B'; $wire.setTab('3_ASSR_B2B')" class="flex-1 relative z-10 py-2.5 text-sm sm:text-[15px] font-bold rounded-full transition-colors duration-300" :class="localTab === '3_ASSR_B2B' ? 'text-white' : 'text-gray-600 hover:text-gray-900'">
            ASSURANCE B2B
        </button>
    </div>
    
    <!-- Teks Info Print -->
    <div class="hidden export-show-text text-center text-lg font-bold text-text-main my-6 bg-surface-subtle p-3 rounded-full border border-border-card">
        Tabel Data: @if($activeTab === '1_PSB_B2C') PSB B2C @elseif($activeTab === '2_ASSR_B2C') ASSURANCE B2C @else ASSURANCE B2B @endif
    </div>

    <!-- BOX 3: Data Tabel Utama -->
    <div class="bg-surface-card border border-border-card rounded-[32px] shadow-sm relative z-0 p-4 sm:p-6 min-h-[400px]">
        <div class="overflow-x-auto custom-scrollbar pb-2">
            <table class="w-full text-left border-separate border-spacing-0">
                <thead>
                    <tr>
                        @foreach($tableHeaders as $header)
                            <th class="px-4 py-4 font-bold text-text-main uppercase tracking-wider text-[11px] bg-gray-100 align-middle min-w-[90px] {{ $loop->first ? 'rounded-l-full' : '' }}">
                                <button wire:click="sortBy('{{ $header }}')" class="flex flex-col items-center justify-center w-full focus:outline-none hover:text-telkom-red transition-colors text-center leading-snug">
                                    <span class="whitespace-pre-line">{{ $header }}</span>
                                    @if($sortColumn === $header)
                                        <span class="mt-1 text-telkom-red shrink-0 export-btn-hide">{{ $sortDirection === 'asc' ? '?' : '?' }}</span>
                                    @endif
                                </button>
                            </th>
                        @endforeach
                        <th class="no-export px-4 py-4 font-bold text-text-main uppercase tracking-wider text-[11px] bg-gray-100 rounded-r-full text-center align-middle min-w-[100px]">Aksi</th>
                    </tr>
                </thead>
                <tbody class="[&>tr:not(:last-child)>td]:border-b [&>tr:not(:last-child)>td]:border-border-card/50 text-[13px] text-text-main">
                    @forelse($displayData as $row)
                        <tr class="hover:bg-surface-subtle transition-colors group">
                            @foreach($tableHeaders as $header)
                                <td class="px-4 py-4 text-[13px] text-center whitespace-nowrap {{ (strpos(strtoupper($header), 'SKOR AKHIR') !== false || strpos(strtoupper($header), 'WORLDSKILLS') !== false) ? 'font-bold text-telkom-red' : 'text-text-main' }}">
                                    {{ $row[$header] ?? '-' }}
                                </td>
                            @endforeach
                            <td class="no-export px-4 py-4 text-center whitespace-nowrap sticky right-0 bg-surface-card group-hover:bg-surface-subtle transition-colors">
                                <button class="p-1.5 sm:px-4 sm:py-1.5 rounded-lg sm:rounded-full bg-white border border-border-card text-text-muted hover:text-telkom-red hover:border-telkom-red shadow-sm transition-all flex items-center justify-center mx-auto" title="Edit">
                                    <svg class="w-4 h-4 sm:mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                    <span class="hidden sm:inline text-xs font-bold">Edit</span>
                                </button>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="{{ count($tableHeaders) + 1 }}" class="px-5 py-8 text-center text-text-muted">
                                Belum ada data atau tidak ditemukan.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
