<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote')->hourly();

// Jadwalkan tarik data otomatis setiap menit
Schedule::command('sheet:sync')
    ->everyMinute()
    ->withoutOverlapping();

Schedule::command('sheet:sync-sobi')->everyMinute()->withoutOverlapping();
